package com.example.sravani.daana;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.TabLayout;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.lang.*;
import java.util.ArrayList;
import java.util.List;

import static com.example.sravani.daana.MainActivity.UID;
import static com.example.sravani.daana.MainActivity.accty;
import static com.example.sravani.daana.MainActivity.aemail;
import static com.example.sravani.daana.MainActivity.logstat;
import static java.lang.Long.parseLong;


public class sigUp extends AppCompatActivity {

    private DatabaseReference dbr,dbro,fbu;
    private Toolbar toolbar;
    private ProgressDialog progressDialog;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private int[] tabIcons = {
            R.drawable.user3,
            R.drawable.org,

    };

    private FirebaseAuth fba;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sig_up);

        progressDialog = new ProgressDialog(this);
        fbu = FirebaseDatabase.getInstance().getReference("Accty");
        viewPager = (ViewPager) findViewById(R.id.viewpager);
        setupViewPager(viewPager);

        tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);
        setupTabIcons();
    }

    private void setupTabIcons() {
        tabLayout.getTabAt(0).setIcon(tabIcons[0]);
        tabLayout.getTabAt(1).setIcon(tabIcons[1]);
    }

    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFrag(new OneFragment(), " Donar ");
        adapter.addFrag(new TwoFragment(), " Organization");
        viewPager.setAdapter(adapter);
    }

    public void userSignUp(View view) {

        fba= FirebaseAuth.getInstance();
        dbr =FirebaseDatabase.getInstance().getReference().child("users");
        final TextInputLayout email = (TextInputLayout) findViewById(R.id.usupemail);
        final TextInputLayout pass = (TextInputLayout) findViewById(R.id.usuppass);
        final String eml = email.getEditText().getText().toString();
        final String pas=pass.getEditText().getText().toString();
        final TextInputLayout pin = (TextInputLayout) findViewById(R.id.usuppin);
        final long pinc =  parseLong(pin.getEditText().getText().toString());
        final Button button = (Button) findViewById(R.id.usup);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (email.getEditText().getText().toString().length() == 0) {
                    email.getEditText().setError("Email required");
                    email.getEditText().requestFocus();
                }
                else if (pass.getEditText().getText().toString().length() == 0) {
                    pass.getEditText().setError("Password Required");
                    pass.getEditText().requestFocus();
                }
                else if (pin.getEditText().getText().toString().length() == 0) {
                    pin.getEditText().setError("Pincode is Required");
                    pin.getEditText().requestFocus();
                }
                else if (pin.getEditText().getText().toString().length() != 6) {
                    pin.getEditText().setError("Pincode should be of 6 digits");
                    pin.getEditText().requestFocus();
                }
                else
                {
                    progressDialog.setMessage("Registering User..");
                    progressDialog.show();
                    fba.createUserWithEmailAndPassword(eml,pas)
                            .addOnCompleteListener(sigUp.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()){
                                //display some message here

                                FirebaseUser user = fba.getCurrentUser();
                                dbr.child(user.getUid()).setValue(pinc);
                                String id = fbu.push().getKey();
                                //FirebaseUser user = fba.getCurrentUser();



                                Toast.makeText(sigUp.this,"Successfully registered",Toast.LENGTH_LONG).show();
                                logstat = 1;
                                accty = 1;
                                UID = user.getUid().toString();
                                fbu.child(UID).setValue("1");
                                aemail = email.getEditText().getText().toString();
                                Intent intent = new Intent(sigUp.this, MainActivity.class);
                                startActivity(intent);

                            }else{
                                //display some message here
                                Toast.makeText(sigUp.this,"Registration Error",Toast.LENGTH_LONG).show();
                            }
                            progressDialog.dismiss();

                        }
                    });
            }

            }

        });


    }

    public void orgSignUp(View view) {
        dbro =FirebaseDatabase.getInstance().getReference().child("organisation");
        fba= FirebaseAuth.getInstance();
        final TextInputLayout email = (TextInputLayout) findViewById(R.id.osupemail);
        final TextInputLayout pass = (TextInputLayout) findViewById(R.id.osuppass);
        final TextInputLayout pin = (TextInputLayout) findViewById(R.id.osuppin);
        final TextInputLayout name = (TextInputLayout) findViewById(R.id.osupname);
        final TextInputLayout phone = (TextInputLayout) findViewById(R.id.osupphone);
        final TextInputLayout loc = (TextInputLayout) findViewById(R.id.osuploc);
        final String eml = email.getEditText().getText().toString();
        final String pas=pass.getEditText().getText().toString();

        final TextInputLayout website = (TextInputLayout) findViewById(R.id.osupwebsite);
        final TextInputLayout type = (TextInputLayout) findViewById(R.id.osuptype);
        final Button button = (Button) findViewById(R.id.osup);
        final long epin =Long.parseLong(pin.getEditText().getText().toString());
        final String ename =name.getEditText().getText().toString();
        final String ephone = phone.getEditText().getText().toString();
        final String eloc = loc.getEditText().getText().toString();
        final String eemail =email.getEditText().getText().toString();
        final String ewebsite =website.getEditText().getText().toString();
        final String etype =type.getEditText().getText().toString();
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {


                if (name.getEditText().getText().toString().length() == 0) {
                    name.getEditText().setError("Name of Organization required");
                    name.getEditText().requestFocus();
                }
                else if (type.getEditText().getText().toString().length() == 0) {
                    type.getEditText().setError("Type of organization required");
                    type.getEditText().requestFocus();
                }
                else if (email.getEditText().getText().toString().length() == 0) {
                    email.getEditText().setError("Email required");
                    email.getEditText().requestFocus();
                }
                else if (pass.getEditText().getText().toString().length() == 0) {
                    pass.getEditText().setError("Password Required");
                    pass.getEditText().requestFocus();
                }
                else if (pin.getEditText().getText().toString().length() == 0) {
                    pin.getEditText().setError("Pincode is Required");
                    pin.getEditText().requestFocus();
                }
                else if (pin.getEditText().getText().toString().length() != 6) {
                    pin.getEditText().setError("Pincode should be of 6 digits");
                    pin.getEditText().requestFocus();
                }
                else if (phone.getEditText().getText().toString().length() == 0) {
                    phone.getEditText().setError("Phone number required");
                    phone.getEditText().requestFocus();
                }
                else if (website.getEditText().getText().toString().length() == 0) {
                   // website.getEditText().setError("Website required");
                    //website.getEditText().requestFocus();
                }
                else if (loc.getEditText().getText().toString().length() == 0) {
                    loc.getEditText().setError("Address required");
                    loc.getEditText().requestFocus();
                }
                else
                {
                    progressDialog.setMessage("Registering User..");
                    progressDialog.show();
                    fba.createUserWithEmailAndPassword(eml,pas)
                            .addOnCompleteListener(sigUp.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if(task.isSuccessful()){
                                        //display some message here
                                        Orginfo org =new Orginfo(epin,ename,ephone,eloc,eemail,ewebsite,etype);
                                        FirebaseUser user = fba.getCurrentUser();
                                        dbro.child(user.getUid()).setValue(org);

                                        Toast.makeText(sigUp.this,"Successfully registered",Toast.LENGTH_LONG).show();
                                        logstat = 1;
                                        accty = 0;
                                        UID = user.getUid().toString();
                                        aemail = eemail;
                                       // FirebaseUser user = fba.getCurrentUser();
                                        fbu.child(UID).setValue("0");


                                        Intent intent = new Intent(sigUp.this, MainActivity.class);
                                        startActivity(intent);

                                    }else{
                                        //display some message here
                                        Toast.makeText(sigUp.this,"Registration Error",Toast.LENGTH_LONG).show();
                                    }
                                    progressDialog.dismiss();

                                }
                            });
               }

            }

        });



    }

    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFrag(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }
}
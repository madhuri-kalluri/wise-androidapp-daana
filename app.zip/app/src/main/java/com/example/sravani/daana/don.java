package com.example.sravani.daana;

/**
 * Created by Sravani on 04-03-2017.
 */

public class don {


    public String donId;


    public String donItem;
    public String dondesc;

    public don()
    {

    }

    public don(String donId, String donItem, String dondesc) {
        this.donId = donId;
        this.donItem = donItem;
        this.dondesc = dondesc;
    }
    public String getDonId() {
        return donId;
    }

    public void setDonId(String donId) {
        this.donId = donId;
    }

    public String getDonItem() {
        return donItem;
    }

    public void setDonItem(String donItem) {
        this.donItem = donItem;
    }

    public String getDondesc() {
        return dondesc;
    }

    public void setDondesc(String dondesc) {
        this.dondesc = dondesc;
    }


}

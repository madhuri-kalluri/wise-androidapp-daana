package com.example.sravani.daana;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Donation extends AppCompatActivity {
    EditText e1,e2;
    private DatabaseReference dbr;
    private FirebaseAuth fba;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donation);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        EditText textArea = (EditText) findViewById(R.id.editText2);

        textArea.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                v.getParent().requestDisallowInterceptTouchEvent(true);
                switch (event.getAction() & MotionEvent.ACTION_MASK){
                    case MotionEvent.ACTION_UP:
                        v.getParent().requestDisallowInterceptTouchEvent(false);
                        break;
                }
                return false;
            }
        });
    }

    public void org(View v1)
    {
        e1 = (EditText) findViewById(R.id.editText);
        e2 = (EditText) findViewById(R.id.editText2);
        dbr= FirebaseDatabase.getInstance().getReference("donation");
        fba = FirebaseAuth.getInstance();

        final Button button = (Button) findViewById(R.id.b1_donate);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Perform action on click

                if (e1.getText().toString().length() == 0)
                {
                    e1.setError("Donation Article required");
                    e1.requestFocus();
                }
                else
                {
                    String id = dbr.push().getKey();
                    FirebaseUser user = fba.getCurrentUser();
                    don d = new don(user.getUid(),e1.getText().toString(),e2.getText().toString());
                    dbr.child(id).setValue(d);

                    Intent intent = new Intent(Donation.this, listorg.class);
                    intent.putExtra("donid", id);
                    startActivity(intent);
                }
            }
        });

    }
}

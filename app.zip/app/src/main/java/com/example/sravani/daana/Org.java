package com.example.sravani.daana;

/**
 * Created by Sravani on 04-03-2017.
 */

public class Org {

    String name;

    public Org(String name) {
        // TODO Auto-generated constructor stub
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return this.name;
    }
}

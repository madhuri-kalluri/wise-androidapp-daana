package com.example.sravani.daana;


import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Menu;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

import static com.example.sravani.daana.MainActivity.UID;
import static com.example.sravani.daana.MainActivity.accty;
import static com.example.sravani.daana.MainActivity.logstat;


/**
 * A simple {@link Fragment} subclass.
 */
public class UserFragment extends Fragment {

private FirebaseAuth fba;
    public UserFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fba=FirebaseAuth.getInstance();
               View v = inflater.inflate(R.layout.fragment_user, container, false);
        TextView txt = (TextView) v.findViewById(R.id.tv1);
        Typeface font = Typeface.createFromAsset(getActivity().getAssets(), "AddisAbaba.ttf");
        Button bt1 = (Button) v.findViewById(R.id.b1);
        Typeface font1 = Typeface.createFromAsset(getActivity().getAssets(), "MGLittlelearners.ttf");
        Button bt2 = (Button) v.findViewById(R.id.b2);
        Typeface font2 = Typeface.createFromAsset(getActivity().getAssets(), "MGLittlelearners.ttf");
        Button bt3 = (Button) v.findViewById(R.id.b3);
        Typeface font3 = Typeface.createFromAsset(getActivity().getAssets(), "MGLittlelearners.ttf");
        txt.setTypeface(font);
        bt1.setTypeface(font1);
        bt2.setTypeface(font2);
        bt3.setTypeface(font3);

        Button newPage = (Button)v.findViewById(R.id.b1);
        newPage.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Donation.class);
                startActivity(intent);
            }
        });

        newPage = (Button)v.findViewById(R.id.b2);
        newPage.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), listdon.class);
                startActivity(intent);
            }
        });


        newPage = (Button)v.findViewById(R.id.b3);
        newPage.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                fba.signOut();
                getActivity().finish();
                accty=0;

                logstat=0;
                UID = "";
                Intent intent = new Intent(getActivity(), MainActivity.class);
                startActivity(intent);
            }
        });

        return v;
    }


}

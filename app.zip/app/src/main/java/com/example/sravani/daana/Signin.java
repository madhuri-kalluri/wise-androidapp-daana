package com.example.sravani.daana;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

import static com.example.sravani.daana.MainActivity.UID;
import static com.example.sravani.daana.MainActivity.accty;
import static com.example.sravani.daana.MainActivity.aemail;
import static com.example.sravani.daana.MainActivity.logstat;

public class Signin extends AppCompatActivity {
    private FirebaseAuth fba;
    private DatabaseReference fbr,fbu;
    private ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fba = FirebaseAuth.getInstance();
        fbu = FirebaseDatabase.getInstance().getReference("Accty");
        fbr = FirebaseDatabase.getInstance().getReference("Organisation");
        Log.d(Signin.class.getSimpleName(),"1");

        try {
            if (fba.getCurrentUser() != null) {
                Log.d(Signin.class.getSimpleName(), "2");

                UID = fba.getCurrentUser().getUid().toString();
                Log.d(Signin.class.getSimpleName(), "3");
                fbu.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        GenericTypeIndicator<Map<String, String>> genericTypeIndicator = new GenericTypeIndicator<Map<String, String>>() {};
                        Map<String,String> map = dataSnapshot.getValue(genericTypeIndicator);
                        accty = Integer.parseInt(map.get(UID));

                        Toast.makeText(Signin.this,map.get(UID),Toast.LENGTH_LONG).show();

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
                logstat = 1;

                Intent intent = new Intent(Signin.this, MainActivity.class);
                startActivity(intent);
            }
        }
        catch (Exception e)
        {

        }
        progressDialog = new ProgressDialog(this);

        setContentView(R.layout.activity_signin);
        Log.d(Signin.class.getSimpleName(),"2");

    }
    public void sin(View v1)
    {
        final Button button = (Button) findViewById(R.id.lin);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Perform action on click
                TextInputLayout uname = (TextInputLayout) findViewById(R.id.uname);
                TextInputLayout pass = (TextInputLayout) findViewById(R.id.pass);
                final String email = uname.getEditText().getText().toString();
                final String password = pass.getEditText().getText().toString();
                int acct=0;

                if((uname.getEditText().getText().toString().equals("")))
                {  Context context = getApplicationContext();
                    CharSequence text = "Please enter yor registered email Id.";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }
                else if((pass.getEditText().getText().toString().equals("")))
                {  Context context = getApplicationContext();
                    CharSequence text = "Please enter your password.";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }

                //check in org table
               else if(uname.getEditText().getText().toString().equals("admin@123.com")&&pass.getEditText().getText().toString().equals("admin")) {
                    logstat=1;
                    accty=0;
                    UID = fba.getCurrentUser().getUid().toString();
                    Intent intent = new Intent(Signin.this, MainActivity.class);
                    startActivity(intent);
                }//check in user table
                else if(true) {
                    progressDialog.setMessage("Signing in..");
                    progressDialog.show();
                    fba.signInWithEmailAndPassword(email,password)
                            .addOnCompleteListener(Signin.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    progressDialog.dismiss();
                                    if(task.isSuccessful())
                                    {
                                        finish();

                                        aemail = email;
                                        if(fba.getCurrentUser()!=null) {
                                            Log.d(listreqstatus.class.getSimpleName(), "2");
                                            fbu.addValueEventListener(new ValueEventListener() {
                                                @Override
                                                public void onDataChange(DataSnapshot dataSnapshot) {
                                                    UID = fba.getCurrentUser().getUid().toString();
                                                    GenericTypeIndicator<Map<String, String>> genericTypeIndicator = new GenericTypeIndicator<Map<String, String>>() {};
                                                    Map<String,String> map = dataSnapshot.getValue(genericTypeIndicator);
                                                    accty = Integer.parseInt(map.get(UID));
                                                    Toast.makeText(Signin.this,map.get(UID),Toast.LENGTH_LONG).show();

                                                }

                                                @Override
                                                public void onCancelled(DatabaseError databaseError) {

                                                }
                                            });
                                        }   logstat=1;


                                            Intent intent = new Intent(Signin.this, MainActivity.class);
                                        intent.putExtra("accty", accty);
                                        startActivity(intent);
                                        Toast.makeText(Signin.this,"Successfully logged in",Toast.LENGTH_LONG).show();

                                    }
                                    else
                                    {
                                        Toast.makeText(Signin.this,"Login failed.. Please try again",Toast.LENGTH_LONG).show();

                                    }
                                }
                            });



                }
                else
                {
                    Context context = getApplicationContext();
                    CharSequence text = "Wrong password or username. Please try again";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }
            }
        });

    }

    public void startSup(View view) {
        Intent intent = new Intent(Signin.this, sigUp.class);
        startActivity(intent);
    }
}

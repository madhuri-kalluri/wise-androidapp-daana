package com.example.sravani.daana;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import static com.example.sravani.daana.MainActivity.UID;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

/**
 * Created by Sravani on 05-03-2017.
 */

public class listorg  extends Activity implements View.OnClickListener {

    DatabaseReference fbr;
    DatabaseReference fbrr;
    String donId;
    ListView mListView;
    Button btnShowCheckedItems;
    ArrayList<Org> mOrgs;
    ArrayList<String> OrgIds = new ArrayList<String>();
    MultiSelectionAdapter<Org> mAdapter;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fbrr= FirebaseDatabase.getInstance().getReference("request");
        setContentView(R.layout.activity_listorg);
        bindComponents();
        Intent intent = getIntent();


        donId=intent.getStringExtra("donid");
        init();
        addListeners();

    }

    @Override
    protected void onStart()
    {
        super.onStart();

    }
    private void bindComponents() {
        // TODO Auto-generated method stub
        mListView = (ListView) findViewById(android.R.id.list);
        btnShowCheckedItems = (Button) findViewById(R.id.btnShowCheckedItems);
    }

    private void init() {
        fbr= FirebaseDatabase.getInstance().getReference("organisation");
        fbr.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                OrgIds.add(dataSnapshot.getKey());
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        fbr.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot orgSnap : dataSnapshot.getChildren()) {
                    Orginfo orgin = orgSnap.getValue(Orginfo.class);
                    String pass = orgin.getName()+"\n"+orgin.getType()+"\n"+orgin.getLoc();

                    mOrgs.add(new Org(pass));
                    mAdapter.notifyDataSetChanged();
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        mOrgs = new ArrayList<Org>();
        mAdapter = new MultiSelectionAdapter<Org>(this, mOrgs);
        mListView.setAdapter(mAdapter);
    }

    private void addListeners() {
        // TODO Auto-generated method stub
        btnShowCheckedItems.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        if(mAdapter != null) {
            ArrayList<Org> mArrayOrgs = mAdapter.getCheckedItems();
            Log.d(listorg.class.getSimpleName(), "Selected Items: " + mArrayOrgs.toString());
            for(int i=0;i<mArrayOrgs.size();i++)
            {
               String oID =OrgIds.get( mOrgs.indexOf(mArrayOrgs.get(i)));
                String id = fbrr.push().getKey();


                donreq d = new donreq(donId,UID,oID,1);
                fbrr.child(id).setValue(d);



            }
            Toast.makeText(getApplicationContext(), "Selected Items: " + mArrayOrgs.toString(), Toast.LENGTH_LONG).show();
        }
        Intent intent = new Intent(listorg.this, MainActivity.class);
        startActivity(intent);
    }
}



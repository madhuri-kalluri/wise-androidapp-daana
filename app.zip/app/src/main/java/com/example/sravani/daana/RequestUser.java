package com.example.sravani.daana;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class RequestUser extends AppCompatActivity {
    int DonId =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_user);
        String[] ReqItem = {"Bacon", "Ham", "Tuna", "Candy", "Meatball", "Potato", "Daana", "charity"};
        Intent intent = getIntent();
        DonId = intent.getIntExtra("DonID",0);
        int[] ReqDesc = {DonId, DonId, DonId, DonId, DonId, DonId, DonId, DonId, DonId};

        ListAdapter DAdapter = new RequestUser.C_Adapter1(this, ReqItem, ReqDesc);
        ListView DListView = (ListView) findViewById(R.id.ListView1);
        DListView.setAdapter(DAdapter);


        DListView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        String wc = String.valueOf(parent.getItemAtPosition(position));

                        Toast.makeText(RequestUser.this, wc, Toast.LENGTH_LONG).show();




                    }
                }
        );
    }


    class C_Adapter1 extends ArrayAdapter<String> {
        Context context;
        //int img[];
        int mD1[], mD2[], mD3[];

        public C_Adapter1(Context c, String[] DonateI, int[] DonateD) {
            super(c, R.layout.c_row3, DonateI);
            this.context = c;
            this.mD1 = DonateD;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            LayoutInflater myCustomInflater = LayoutInflater.from(getContext());
            View customView = myCustomInflater.inflate(R.layout.c_row3, parent, false);

            String Itemp = getItem(position);
            TextView itemText = (TextView) customView.findViewById(R.id.item_text);
            //ImageView buckysImage = (ImageView) customView.findViewById(R.id.my_profile_image);
            TextView itemText1 = (TextView) customView.findViewById(R.id.item_text1);
            // TextView itemText2 = (TextView) customView.findViewById(R.id.item_text2);
            // TextView itemText3 = (TextView) customView.findViewById(R.id.item_text3);
            itemText.setText(Itemp);

            //  buckysImage.setImageResource(R.drawable.helping_hand);
            itemText1.setText(Integer.toString(mD1[position]));
            //itemText2.setText(mD2[position]);
            //itemText3.setText(mD3[position]);


            return customView;
        }
    }
}

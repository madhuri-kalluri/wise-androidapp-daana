package com.example.sravani.daana;

/**
 * Created by Sravani on 06-03-2017.
 */

public class donreq {

    public String donId;


    public String userId;
    public String organisationId;
    public int stat;

    public donreq()
    {

    }

    public donreq(String donId, String userId, String organisationId,int stat) {
        this.donId = donId;
        this.userId = userId;
        this.organisationId = organisationId;
        this.stat=stat;
    }
    public int getStat() {
        return stat;
    }

    public void setStat(int stat) {
        this.stat = stat;
    }

    public String getDonId() {
        return donId;
    }

    public void setDonId(String donId) {
        this.donId = donId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getOrganisationId() {
        return organisationId;
    }

    public void setOrganisationId(String organisationId) {
        this.organisationId = organisationId;
    }
}

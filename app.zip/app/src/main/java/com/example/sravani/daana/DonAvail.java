package com.example.sravani.daana;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class DonAvail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_don_avail);
        String[] DonItem = {"Bacon", "Ham", "Tuna", "Candy", "Meatball", "Potato", "Daana", "charity"};
        String[] DonDesc = {"i1", "i2", "i3", "i4", "i5", "i6", "i7", "i8", "i9"};
        ListAdapter DAdapter = new DonAvail.C_Adapter1(this, DonItem, DonDesc);
        ListView DListView = (ListView) findViewById(R.id.ListView1);
        DListView.setAdapter(DAdapter);

        DListView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        String wc = String.valueOf(parent.getItemAtPosition(position));

                        Toast.makeText(DonAvail.this, wc, Toast.LENGTH_LONG).show();

                        //Intent myIntent = new Intent(DonAvail.this, RequestUser.class);
                        //myIntent.putExtra("DonID", position);
                        //myIntent.putExtra("lastName", "Your Last Name Here");
                        //startActivity(myIntent);
                    }
                }
        );
    }


    class C_Adapter1 extends ArrayAdapter<String> {
        Context context;
        //int img[];
        String mD1[], mD2[], mD3[];

        public C_Adapter1(Context c, String[] DonateI, String[] DonateD) {
            super(c, R.layout.c_row, DonateI);
            this.context = c;
            this.mD1 = DonateD;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            LayoutInflater myCustomInflater = LayoutInflater.from(getContext());
            View customView = myCustomInflater.inflate(R.layout.c_row, parent, false);

            String Itemp = getItem(position);
            TextView itemText = (TextView) customView.findViewById(R.id.item_text);
            //ImageView buckysImage = (ImageView) customView.findViewById(R.id.my_profile_image);
            TextView itemText1 = (TextView) customView.findViewById(R.id.item_text1);
            // TextView itemText2 = (TextView) customView.findViewById(R.id.item_text2);
            // TextView itemText3 = (TextView) customView.findViewById(R.id.item_text3);
            itemText.setText(Itemp);

            //  buckysImage.setImageResource(R.drawable.helping_hand);
            itemText1.setText(mD1[position]);



            return customView;
        }
    }
}
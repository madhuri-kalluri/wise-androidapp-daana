package com.example.sravani.daana;

/**
 * Created by Sravani on 04-03-2017.
 */

public class Orginfo {



    public long pin;
    public String name;
    public String phone;
    public String loc;

    public long getPin() {
        return pin;
    }

    public void setPin(long pin) {
        this.pin = pin;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getLoc() {
        return loc;
    }

    public void setLoc(String loc) {
        this.loc = loc;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String email;
    public String website ;
    public String type;
    public int accty=0;

    public Orginfo()
    {

    }
    public Orginfo(long pin, String name, String phone, String loc, String email, String website, String type) {
        this.pin = pin;
        this.name = name;
        this.phone = phone;
        this.loc = loc;
        this.email = email;
        this.website = website;
        this.type = type;
    }


}

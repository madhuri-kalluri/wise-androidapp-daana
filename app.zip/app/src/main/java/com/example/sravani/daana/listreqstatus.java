package com.example.sravani.daana;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.client.Firebase;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import static com.example.sravani.daana.MainActivity.UID;

public class listreqstatus extends AppCompatActivity {

    DatabaseReference fbr,fbro;
    Query tp;
    ListView mListView;
    String name,type,loc,pass;
    ArrayAdapter<String> listAdapter;
    ArrayList<String> donList = new ArrayList<String>();
    ArrayList<donreq> list = new ArrayList<donreq>();
    final Context context = this;

    String stat[]= new String[3];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listreqstatus);
        mListView = (ListView) findViewById(R.id.list);
        Intent intent = getIntent();
        stat[0]="Request Sent";
         stat[1]="Request Confirmed"; stat[2]="Donation Complete";
        final String fName = intent.getStringExtra("donid");
        listAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, donList);
        fbr = FirebaseDatabase.getInstance().getReference("request");
        fbro = FirebaseDatabase.getInstance().getReference("organisation");
        mListView.setAdapter(listAdapter);
        mListView.setAdapter(listAdapter);
        //seraching requests
        fbr.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                final donreq orgin = dataSnapshot.getValue(donreq.class);
                final String organId =orgin.getOrganisationId();
                if(orgin.getUserId().equals(UID))
                //seraching for organisation details
                {

                    fbro.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot1) {
                            for(DataSnapshot orgSnap : dataSnapshot1.getChildren()) {
                                Log.d(listreqstatus.class.getSimpleName(),"2");

                                String ch = orgSnap.getKey();
                                if(organId.equals(ch)&&orgin.getDonId().equals(fName)) {
                                    Orginfo orgin1 = orgSnap.getValue(Orginfo.class);
                                    list.add(orgin);
                                    Log.d(listreqstatus.class.getSimpleName(),"3");
                                    String pass = orgin1.getName() + "\n" + orgin1.getType() + "\n" + orgin1.getLoc()+"\n"+ stat[orgin.getStat()-1];
                                    Log.d(listreqstatus.class.getSimpleName(), "4");

                                    donList.add(pass);
                                }
                                listAdapter.notifyDataSetChanged();
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });
                }


            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


        mListView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        String wc = String.valueOf(parent.getItemAtPosition(position));
                        //dbr.child(user.getUid()).setValue(pinc);

                        int s = list.get(position).getStat();
                        if(s==1)
                        {
                            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                                    context);

                            // set title
                            alertDialogBuilder.setTitle("Status");

                            // set dialog message
                            alertDialogBuilder
                                    .setMessage("Organisation is considering your request")
                                    .setCancelable(false)

                                    .setNegativeButton("Ok",new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog,int id) {
                                            // if this button is clicked, just close
                                            // the dialog box and do nothing
                                            dialog.cancel();
                                        }
                                    });

                            // create alert dialog
                            AlertDialog alertDialog = alertDialogBuilder.create();

                            // show it
                            alertDialog.show();
                        }


                        else if(s==2) {

                                // TODO Auto-generated method stub
                                final Dialog dialog = new Dialog(listreqstatus.this);
                                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                dialog.setContentView(R.layout.customdialog);

                                final EditText editText = (EditText) dialog.findViewById(R.id.editText1);
                                Button button = (Button) dialog.findViewById(R.id.button1);
                                button.setOnClickListener(new View.OnClickListener() {

                                    @Override
                                    public void onClick(View v) {
                                        // TODO Auto-generated method stub
                                        //_textDialog.setText(editText.getText().toString());
                                        dialog.dismiss();
                                    }
                                });

                                dialog.show();



                        }
                        else if(s==3)
                        {

                            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                                    context);

                            // set title
                            alertDialogBuilder.setTitle("Status");

                            // set dialog message
                            alertDialogBuilder
                                    .setMessage("Your details have been sent to the Organization..They will contact you ")
                                    .setCancelable(false)

                                    .setNegativeButton("Ok",new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog,int id) {
                                            // if this button is clicked, just close
                                            // the dialog box and do nothing
                                            dialog.cancel();
                                        }
                                    });

                            // create alert dialog
                            AlertDialog alertDialog = alertDialogBuilder.create();

                            // show it
                            alertDialog.show();
                        }

                    }
                }
        );
    }
}
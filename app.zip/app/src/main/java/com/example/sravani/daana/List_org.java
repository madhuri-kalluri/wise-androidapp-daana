package com.example.sravani.daana;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class List_org extends AppCompatActivity {

    ListAdapter DAdapter;
    ListView DListView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_org);
        String[] Orgname = {"Bacon", "Ham", "Tuna", "Candy", "Meatball", "Potato","Daana","charity"};
        String[] Type={"i1","i2","i3","i4","i5","i6","i7","i8","i9"};
        String[] Location={"i1","i2","i3","i4","i5","i6","i7","i8","i9"};
        int[] pos ={0};
         DAdapter = new C_Adapter1(this,Orgname,Type,Location);
        DListView = (ListView) findViewById(R.id.ListView1);
        DListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        DListView.setAdapter(DAdapter);

        DListView.setOnItemClickListener(
                new AdapterView.OnItemClickListener(){
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        String wc = String.valueOf(parent.getItemAtPosition(position));

                        Toast.makeText(List_org.this, wc, Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    public void org(View v1)
    {
        final Button button = (Button) findViewById(R.id.testbutton);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                DListView.setOnItemClickListener(
                        new AdapterView.OnItemClickListener(){
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                String wc="";
                                int i=0;
                                DListView = (ListView) findViewById(R.id.ListView1);
                                long[] pos=DListView.getCheckedItemIds();
                                while (i<pos.length)
                                wc = wc + Long.toString(pos[i])+"\n";

                                Toast.makeText(List_org.this, wc, Toast.LENGTH_LONG).show();

                                //String wc = String.valueOf(parent.getItemAtPosition(position));

                                //Toast.makeText(List_org.this, wc, Toast.LENGTH_LONG).show();
                            }
                        }
                );
                // Perform action on click
                //Intent intent = new Intent(List_org.this, MainActivity.class);
                //startActivity(intent);
            }
        });

    }

}
class C_Adapter1 extends ArrayAdapter<String> {
    Context context;
    //int img[];
    String mD1[],mD2[],mD3[];

    public C_Adapter1(Context c, String[] orgN,String[] typ,String Loc[]) {
        super(c,R.layout.c_row2 ,orgN);
        this.context= c;
        this.mD1=typ;
        this.mD2=Loc;

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater myCustomInflater = LayoutInflater.from(getContext());
        View customView = myCustomInflater.inflate(R.layout.c_row2, parent, false);

        String Itemp = getItem(position);
        TextView itemText = (TextView) customView.findViewById(R.id.item_text);
        //ImageView buckysImage = (ImageView) customView.findViewById(R.id.my_profile_image);
        TextView itemText1 = (TextView) customView.findViewById(R.id.item_text1);
        TextView itemText2 = (TextView) customView.findViewById(R.id.item_text2);
       // TextView itemText3 = (TextView) customView.findViewById(R.id.item_text3);
       itemText.setText(Itemp);

      //  buckysImage.setImageResource(R.drawable.helping_hand);
        itemText1.setText(mD1[position]);
        itemText2.setText(mD2[position]);
        //itemText3.setText(mD3[position]);


        return customView;
    }
}
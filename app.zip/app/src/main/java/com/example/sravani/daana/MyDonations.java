package com.example.sravani.daana;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MyDonations extends AppCompatActivity {

    List<String> donitem = new ArrayList<String>();
    List<String> dondesc = new ArrayList<String>();
    ListAdapter DAdapter;
    ListView DListView;
    StringBuffer S;
    DatabaseReference fbr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_donations);
        fbr= FirebaseDatabase.getInstance().getReference("donation");
        init();

        DListView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        String wc = String.valueOf(parent.getItemAtPosition(position));

                        Toast.makeText(MyDonations.this, wc, Toast.LENGTH_LONG).show();

                        Intent myIntent = new Intent(MyDonations.this, RequestUser.class);
                        myIntent.putExtra("DonID", position);
                        startActivity(myIntent);
                    }
                }
        );
    }

    public void init()
    {
         S = new StringBuffer("Test");

        fbr.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                for (DataSnapshot orgSnap : dataSnapshot.getChildren()) {
                    don donate = orgSnap.getValue(don.class);
                    donitem.add(donate.getDonItem());
                    dondesc.add(donate.getDondesc());
                    Toast.makeText(getApplicationContext(), donate.getDonItem(), Toast.LENGTH_LONG).show();


                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        Toast.makeText(getApplicationContext(),S, Toast.LENGTH_LONG).show();
        String[] DonItem = new String[donitem.size()];
        DonItem = donitem.toArray(DonItem);
        String[] DonDesc = new String[dondesc.size()];
        DonDesc = donitem.toArray(DonDesc);

        DAdapter = new C_Adapter1(this, DonItem, DonDesc);
        DListView = (ListView) findViewById(R.id.ListView1);
        DListView.setAdapter(DAdapter);

    }

    class C_Adapter1 extends ArrayAdapter<String> {
        Context context;
        //int img[];
        String mD1[], mD2[], mD3[];

        public C_Adapter1(Context c, String[] DonateI, String[] DonateD) {
            super(c, R.layout.c_row, DonateI);
            this.context = c;
            this.mD1 = DonateD;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            LayoutInflater myCustomInflater = LayoutInflater.from(getContext());
            View customView = myCustomInflater.inflate(R.layout.c_row, parent, false);

            String Itemp = getItem(position);
            TextView itemText = (TextView) customView.findViewById(R.id.item_text);
            //ImageView buckysImage = (ImageView) customView.findViewById(R.id.my_profile_image);
            TextView itemText1 = (TextView) customView.findViewById(R.id.item_text1);
            itemText.setText(Itemp);
           itemText1.setText(mD1[position]);
            return customView;
        }
    }
}
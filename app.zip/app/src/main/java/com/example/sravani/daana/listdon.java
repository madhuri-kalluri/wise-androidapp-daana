package com.example.sravani.daana;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import static com.example.sravani.daana.MainActivity.UID;

/**
 * Created by Sravani on 05-03-2017.
 */

public class listdon  extends Activity {

    DatabaseReference fbr;
    ListView mListView;
    ArrayAdapter<String> listAdapter ;
    ArrayList<String> donList = new ArrayList<String>();
    ArrayList<String> donIds = new ArrayList<String>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listdon);
        mListView = (ListView) findViewById(R.id.list);

        listAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,donList);
        fbr= FirebaseDatabase.getInstance().getReference("donation");
        mListView.setAdapter(listAdapter);
        fbr.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                    don orgin = dataSnapshot.getValue(don.class);
                    String pass = orgin.getDonItem()+"\n"+orgin.getDondesc();
                    if(orgin.getDonId().equals(UID))
                    donList.add(pass);
                    donIds.add(dataSnapshot.getKey());
                    listAdapter.notifyDataSetChanged();

            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        mListView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        String wc = String.valueOf(parent.getItemAtPosition(position));

                        Intent myIntent = new Intent(listdon.this, listreqstatus.class);
                        myIntent.putExtra("donid", donIds.get(position));
                        startActivity(myIntent);
                    }
                }
        );
    }

}
